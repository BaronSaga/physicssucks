''''
Created on 10/3/17
@author:   Dev Patel
Pledge:    I pledge my honor that I have abided by the Stevens Honor System
            -dpate91

CS115 - Hw 4
'''
def reverse(lst):
    '''Using this cuz im lazy and it gets the job done'''
    if lst == []:
        return []
    else:
        return reverse(lst[1:]) + [lst[0]]

def pascal_add(lst):
    '''adds stuff'''
    if len(lst) <= 1:
        return []
    return [lst[0] + lst[1]] + pascal_add(lst[1:])

def pascal_row(n):
    '''finds the nth row of the pascal triangle (with 0 being the first) and returns it'''
    def row_helper(n, lst):
        '''here because I need a lst'''
        if n == 0:
            return [1]
        if n == 1:
            return [1, 1]
        return [1] + pascal_add(row_helper(n - 1, lst)) + [1]
    return row_helper(n, [])

def pascal_triangle(n):
    '''finds the full pascal triangle up to the pascal_row of n above. 0 is stil first'''
    def triangle_helper(n, lst):
        '''same as row_helper but with the full triangle'''
        if n == 0:
            return [pascal_row(n)]
        lst = [pascal_row(n)]
        return lst + triangle_helper(n-1, lst)
    return reverse(triangle_helper(n, []))